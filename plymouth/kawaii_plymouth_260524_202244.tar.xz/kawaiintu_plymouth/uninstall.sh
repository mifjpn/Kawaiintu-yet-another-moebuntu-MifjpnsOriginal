#!/bin/bash
set -e

THEME_NAME="kawaiintu"
DEST_DIR="/usr/share/plymouth/themes/${THEME_NAME}"
PLYMOUTH_CONF="${DEST_DIR}/${THEME_NAME}.plymouth"

if [ "$EUID" -ne 0 ]; then
  echo "[!] エラー: sudo で実行してください。"
  exit 1
fi

echo "[*] Kawaiintu Plymouth テーマをアンインストールします..."

# alternatives の設定から Kawaiintu を削除
update-alternatives --remove default.plymouth "$PLYMOUTH_CONF" >/dev/null 2>&1 || true

# Ubuntu標準のテーマを明示的に探して確実に復元する
if [ -f "/usr/share/plymouth/themes/bgrt/bgrt.plymouth" ]; then
    echo "[*] 標準テーマ (bgrt) を復元します..."
    update-alternatives --set default.plymouth /usr/share/plymouth/themes/bgrt/bgrt.plymouth
elif [ -f "/usr/share/plymouth/themes/ubuntu-logo/ubuntu-logo.plymouth" ]; then
    echo "[*] 標準テーマ (ubuntu-logo) を復元します..."
    update-alternatives --set default.plymouth /usr/share/plymouth/themes/ubuntu-logo/ubuntu-logo.plymouth
elif [ -f "/usr/share/plymouth/themes/spinner/spinner.plymouth" ]; then
    echo "[*] 標準テーマ (spinner) を復元します..."
    update-alternatives --set default.plymouth /usr/share/plymouth/themes/spinner/spinner.plymouth
else
    # 万が一標準が見つからない場合のフォールバック
    update-alternatives --auto default.plymouth
fi

# システム上のカスタムテーマ本体を削除
rm -rf "$DEST_DIR"

echo "[*] initramfs を更新しています..."
update-initramfs -u
echo "[+] アンインストール完了。システムの標準テーマに戻りました。"
