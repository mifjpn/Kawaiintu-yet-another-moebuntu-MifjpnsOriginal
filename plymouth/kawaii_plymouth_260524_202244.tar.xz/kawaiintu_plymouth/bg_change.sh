#!/bin/bash
set -e

DEST_DIR="/usr/share/plymouth/themes/kawaiintu"
TARGET_BG="${DEST_DIR}/background-tile.png"

if [ "$EUID" -ne 0 ]; then
  echo "[!] エラー: sudo で実行してください。"
  exit 1
fi

if ! command -v convert >/dev/null 2>&1; then
    echo "[*] 必要なパッケージ (imagemagick) をインストールしています..."
    apt-get update -qq && apt-get install -y imagemagick
fi

if [ -z "$1" ] || [ ! -f "$1" ]; then
    echo "[*] 指定がないため、背景を黒（デフォルト）にリセットします。"
    rm -f "$TARGET_BG"
else
    echo "[*] 背景画像をFHDにクロップして適用します: $1"
    convert "$1" -resize 1920x1080^ -gravity center -extent 1920x1080 "$TARGET_BG"
    chmod 644 "$TARGET_BG"
fi

update-initramfs -u
echo "[+] 背景の変更完了！"
