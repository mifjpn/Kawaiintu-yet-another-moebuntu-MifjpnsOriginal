#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THEME_NAME="kawaiintu"
DEST_DIR="/usr/share/plymouth/themes/${THEME_NAME}"
SRC_DIR="${SCRIPT_DIR}/kawaiintu_theme_set"

if [ "$EUID" -ne 0 ]; then
  echo "[!] エラー: sudo で実行してください。"
  exit 1
fi

if [ ! -d "$SRC_DIR" ]; then
  echo "[!] エラー: テーマフォルダ ($SRC_DIR) が見つかりません。"
  exit 1
fi

if ! dpkg -l | grep -qw plymouth-themes; then
    echo "[*] 必要なパッケージ (plymouth-themes) をインストールしています..."
    apt-get update -qq && apt-get install -y plymouth-themes
fi

echo "[*] Kawaiintu Plymouth のインストールを開始します..."
rm -rf "$DEST_DIR"
cp -r "$SRC_DIR" "$DEST_DIR"

# インストール時は必ず背景を黒(デフォルト)にリセット
rm -f "$DEST_DIR/background-tile.png"

update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth "$DEST_DIR/${THEME_NAME}.plymouth" 200
update-alternatives --set default.plymouth "$DEST_DIR/${THEME_NAME}.plymouth"
update-initramfs -u

echo "[+] インストール完了！"
