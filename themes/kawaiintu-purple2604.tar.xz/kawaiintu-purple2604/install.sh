#!/bin/bash
set -e

# Get the directory of this script and theme name
THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THEME_NAME="$(basename "${THEME_DIR}")"
GREETER_CONF="/etc/gdm3/greeter.dconf-defaults"

if [ "$EUID" -ne 0 ]; then
  echo "[!] Error: This script must be run as root (sudo)."
  exit 1
fi

# 1. Setup workspace in the user's home directory
if [ -n "$SUDO_USER" ]; then
    USER_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    USER_HOME=$HOME
fi
BUILD_DIR="${USER_HOME}/.kawaiintu_build/${THEME_NAME}"

echo "=================================================="
echo " [*] Kawaiintu Setup Script (${THEME_NAME})"
echo " [*] Workspace: ${BUILD_DIR}"
echo "=================================================="

echo "[*] Checking for required tools..."
if ! command -v glib-compile-resources &> /dev/null; then
    apt-get update
    apt-get install -y libglib2.0-dev-bin
fi
if ! command -v convert &> /dev/null; then
    echo "[*] Installing ImageMagick..."
    apt-get update
    apt-get install -y imagemagick
fi
if ! dpkg -l | grep -qw "gnome-shell-extensions"; then
    echo "[*] Installing gnome-shell-extensions..."
    apt-get install -y gnome-shell-extensions
fi

# 2. Copy assets to the workspace to keep the Git repository clean
echo "[*] Preparing build assets in the workspace..."
rm -rf "${BUILD_DIR}"
mkdir -p "${BUILD_DIR}"
cp -r "${THEME_DIR}/gnome-shell" "${BUILD_DIR}/"
cp -r "${THEME_DIR}/gtk-3.0" "${BUILD_DIR}/" 2>/dev/null || true
cp -r "${THEME_DIR}/gtk-4.0" "${BUILD_DIR}/" 2>/dev/null || true
cp -r "${THEME_DIR}/bin" "${BUILD_DIR}/"

# 3. Detect resolution and perform dynamic resizing
echo "[*] Detecting display resolution and optimizing background..."
RES=""
for mode_file in /sys/class/drm/*/modes; do
    if [ -f "$mode_file" ]; then
        res_val=$(head -n 1 "$mode_file" 2>/dev/null)
        if [ -n "$res_val" ]; then
            RES="$res_val"
            break
        fi
    fi
done
[ -z "$RES" ] && RES="1920x1080"
echo "    -> Detected resolution: ${RES}"

if [ -f "${BUILD_DIR}/gnome-shell/default-background.png" ]; then
    convert "${BUILD_DIR}/gnome-shell/default-background.png" -resize "${RES}^" -gravity center -extent "${RES}" "${BUILD_DIR}/login-background.png"
    chmod 644 "${BUILD_DIR}/login-background.png"
fi

# 4. Synchronize dark CSS files
echo "[*] Synchronizing dark CSS..."
if [ -f "${BUILD_DIR}/gnome-shell/gnome-shell.css" ]; then
    cp -f "${BUILD_DIR}/gnome-shell/gnome-shell.css" "${BUILD_DIR}/gnome-shell/gnome-shell-dark.css"
fi
if [ -f "${BUILD_DIR}/gtk-4.0/gtk.css" ]; then
    cp -f "${BUILD_DIR}/gtk-4.0/gtk.css" "${BUILD_DIR}/gtk-4.0/gtk-dark.css"
fi
if [ -f "${BUILD_DIR}/gtk-3.0/gtk.css" ]; then
    cp -f "${BUILD_DIR}/gtk-3.0/gtk.css" "${BUILD_DIR}/gtk-3.0/gtk-dark.css"
fi

# 5. GDM configuration and resource compilation
echo "[*] Disabling GDM logo..."
sed -i "s|^#* *logo=.*|logo=''|g" "$GREETER_CONF"
sed -i "s|^#* *fallback-logo=.*|fallback-logo=''|g" "$GREETER_CONF"
dconf update

echo "[*] Running gresource compiler script..."
if [ -f "${BUILD_DIR}/bin/install_gdm_bg.py" ]; then
    python3 "${BUILD_DIR}/bin/install_gdm_bg.py" "${BUILD_DIR}"
else
    echo "[!] Error: ${BUILD_DIR}/bin/install_gdm_bg.py not found."
    exit 1
fi

# 6. Apply desktop environment tweaks
echo "[*] Applying Kawaiintu desktop environment tweaks..."
if [ -n "$SUDO_USER" ]; then
    REAL_UID=$(id -u "$SUDO_USER")
    export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${REAL_UID}/bus"
    
    sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" gnome-extensions enable user-theme@gnome-shell-extensions.gcampax.github.com || true
    
    sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" dconf write /org/gnome/desktop/interface/gtk-theme "'$THEME_NAME'"
    sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" dconf write /org/gnome/shell/extensions/user-theme/name "'$THEME_NAME'"
fi

echo "=================================================="
echo "[+] ${THEME_NAME} installation completed successfully!"
echo "    (Debug assets are preserved in ${BUILD_DIR})"
echo "    Please restart GDM by running: sudo systemctl restart gdm3"
echo "=================================================="
