#!/bin/bash
set -e

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_IMG="${THEME_DIR}/login-background.png"

echo "=================================================="
echo " [*] Kawaiintu Login Background Change Tool"
echo "=================================================="

if [ "$EUID" -ne 0 ]; then
  echo "[!] Error: This script must be run with sudo."
  exit 1
fi

echo "[*] Checking for required tools (ImageMagick)..."
if ! command -v convert &> /dev/null; then
    echo "[-] ImageMagick not found. Starting automatic installation..."
    apt-get update
    apt-get install -y imagemagick
    echo "[+] Installation complete."
fi

# Fallback if no argument is provided or file does not exist
if [ -z "$1" ] || [ ! -f "$1" ]; then
    echo "[*] Image not specified or not found."
    echo "[*] Generating and applying default dark background (#222222)..."
    # Generate 1920x1080 solid color PNG using ImageMagick
    convert -size 1920x1080 xc:"#222222" "$TARGET_IMG"
else
    SRC_IMG="$1"
    echo "[*] Converting and applying the specified image to optimal PNG format..."
    convert "$SRC_IMG" "$TARGET_IMG"
fi

chmod 644 "$TARGET_IMG"

# Re-run encapsulation script if it exists to apply to GDM
BIN_DIR="${THEME_DIR}/bin"
if [ -f "${BIN_DIR}/install_gdm_bg.py" ]; then
    echo "[*] Executing capsule generation script to apply image to GDM..."
    python3 "${BIN_DIR}/install_gdm_bg.py" "${THEME_DIR}"
fi

echo "=================================================="
echo "[+] Changes applied successfully!"
echo "    The new image will be applied upon next logout or boot."
echo "    * You can check immediately with: sudo systemctl restart gdm3"
echo "=================================================="
