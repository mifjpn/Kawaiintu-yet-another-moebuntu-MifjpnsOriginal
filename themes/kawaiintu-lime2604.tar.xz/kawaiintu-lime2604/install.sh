#!/bin/bash
set -e

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THEME_NAME="$(basename "${THEME_DIR}")"
BIN_DIR="${THEME_DIR}/bin"
GREETER_CONF="/etc/gdm3/greeter.dconf-defaults"

echo "=================================================="
echo " [*] Kawaiintu Setup Script (${THEME_NAME})"
echo "=================================================="

if [ "$EUID" -ne 0 ]; then
  echo "[!] Error: This script must be run with sudo."
  exit 1
fi

echo "[*] Checking required tools..."
if ! command -v glib-compile-resources &> /dev/null; then
    apt-get update
    apt-get install -y libglib2.0-dev-bin
fi

if ! dpkg -l | grep -qw "gnome-shell-extensions"; then
    echo "[*] Installing gnome-shell-extensions..."
    apt-get install -y gnome-shell-extensions
fi

echo "[*] Resetting login background and syncing dark CSS..."
if [ -f "${THEME_DIR}/gnome-shell/default-background.png" ]; then
    cp -f "${THEME_DIR}/gnome-shell/default-background.png" "${THEME_DIR}/login-background.png"
    chmod 644 "${THEME_DIR}/login-background.png"
fi

if [ -f "${THEME_DIR}/gnome-shell/gnome-shell.css" ]; then
    cp -f "${THEME_DIR}/gnome-shell/gnome-shell.css" "${THEME_DIR}/gnome-shell/gnome-shell-dark.css"
fi
if [ -f "${THEME_DIR}/gtk-4.0/gtk.css" ]; then
    cp -f "${THEME_DIR}/gtk-4.0/gtk.css" "${THEME_DIR}/gtk-4.0/gtk-dark.css"
fi
if [ -f "${THEME_DIR}/gtk-3.0/gtk.css" ]; then
    cp -f "${THEME_DIR}/gtk-3.0/gtk.css" "${THEME_DIR}/gtk-3.0/gtk-dark.css"
fi

echo "[*] Hiding GDM logo..."
sed -i "s|^#* *logo=.*|logo=''|g" "$GREETER_CONF"
sed -i "s|^#* *fallback-logo=.*|fallback-logo=''|g" "$GREETER_CONF"
dconf update

echo "[*] Executing capsule generation script..."
if [ -f "${BIN_DIR}/install_gdm_bg.py" ]; then
    python3 "${BIN_DIR}/install_gdm_bg.py" "${THEME_DIR}"
else
    echo "[!] Error: ${BIN_DIR}/install_gdm_bg.py not found."
    exit 1
fi

echo "[*] Forcing desktop environment tweaks to Kawaiintu..."
if [ -n "$SUDO_USER" ]; then
    REAL_UID=$(id -u "$SUDO_USER")
    export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${REAL_UID}/bus"
    
    sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" gnome-extensions enable user-theme@gnome-shell-extensions.gcampax.github.com || true
    
    sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" dconf write /org/gnome/desktop/interface/gtk-theme "'$THEME_NAME'"
    sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" dconf write /org/gnome/shell/extensions/user-theme/name "'$THEME_NAME'"
fi

echo "=================================================="
echo "[+] Installation process for ${THEME_NAME} is complete!"
echo "    Please restart GDM with: sudo systemctl restart gdm3"
echo "=================================================="
