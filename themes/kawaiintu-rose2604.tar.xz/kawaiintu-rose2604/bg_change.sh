#!/bin/bash
set -e

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THEME_NAME="$(basename "${THEME_DIR}")"

if [ -n "$SUDO_USER" ]; then
    USER_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    USER_HOME=$HOME
fi
BUILD_DIR="${USER_HOME}/.kawaiintu_build/${THEME_NAME}"
TARGET_IMG="${BUILD_DIR}/gnome-shell/login-background.png"
BIN_DIR="${THEME_DIR}/bin"

echo "=================================================="
echo " [*] Kawaiintu Login Background Change Tool"
echo "=================================================="

if [ "$EUID" -ne 0 ]; then
  echo "[!] エラー: このスクリプトは sudo で実行してください。"
  exit 1
fi

if ! command -v convert >/dev/null 2>&1; then
    echo "[*] ImageMagick (convert) が見つかりません。自動インストールを開始します..."
    apt-get update && apt-get install -y imagemagick
fi
if ! command -v xrandr >/dev/null 2>&1; then
    echo "[*] x11-xserver-utils が見つかりません。自動インストールを開始します..."
    apt-get update && apt-get install -y x11-xserver-utils
fi

SCREEN_SIZE=""
if [ -n "$SUDO_USER" ] && [ -n "$DISPLAY" ]; then
    SCREEN_SIZE=$(sudo -u "$SUDO_USER" env DISPLAY="$DISPLAY" xrandr --current 2>/dev/null | grep -oP 'current \K[0-9]+ x [0-9]+' | sed 's/ x /x/')
fi
if [ -z "$SCREEN_SIZE" ]; then
    SCREEN_SIZE=$(xrandr --current 2>/dev/null | grep -oP 'current \K[0-9]+ x [0-9]+' | sed 's/ x /x/')
fi
if [ -z "$SCREEN_SIZE" ]; then
    echo "[!] 仮想キャンバスの取得に失敗しました。ハードウェア(DRM)から物理解像度を取得します..."
    SCREEN_SIZE=$(cat /sys/class/drm/*/modes 2>/dev/null | head -n 1)
fi

[ -z "$SCREEN_SIZE" ] && SCREEN_SIZE="1920x1080"
echo "[*] 検出された仮想キャンバス合計解像度: $SCREEN_SIZE"

if [ -z "$1" ] || [ ! -f "$1" ]; then
    echo "[!] エラー: 画像ファイルが指定されていないか、見つかりません。"
    echo "使い方: sudo ./bg_change.sh /path/to/your/image.jpg"
    exit 1
fi

SRC_IMG="$1"
echo "[*] 画像を ${SCREEN_SIZE} に合わせて敷き詰め(tile)処理を行っています..."

mkdir -p "$(dirname "$TARGET_IMG")"
convert -size "${SCREEN_SIZE}" tile:"$SRC_IMG" "$TARGET_IMG"
chmod 644 "$TARGET_IMG"

if [ -f "${BIN_DIR}/install_gdm_bg.py" ]; then
    echo "[*] GDMへの適用スクリプト (install_gdm_bg.py) を実行します..."
    python3 "${BIN_DIR}/install_gdm_bg.py" "${BUILD_DIR}"
else
    echo "[-] エラー: ${BIN_DIR}/install_gdm_bg.py が見つかりません。"
    exit 1
fi

echo "=================================================="
echo "[+] 完了しました! (適用解像度: $SCREEN_SIZE)"
echo "    次回のログアウトまたは再起動時に新しい背景が適用されます。"
echo "    ※ 今すぐ確認する場合: sudo systemctl restart gdm3"
echo "=================================================="
