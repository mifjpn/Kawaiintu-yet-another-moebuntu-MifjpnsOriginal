#!/bin/bash
set -e

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_IMG="${BUILD_DIR}/gnome-shell/login-background.png"
BIN_DIR="${THEME_DIR}/bin"

echo "=================================================="
echo " [*] Kawaiintu Login Background Change Tool"
echo "=================================================="

if [ "$EUID" -ne 0 ]; then
  echo "[!] エラー: このスクリプトは sudo で実行してください。"
  exit 1
fi

# ImageMagickの存在確認と自動インストール
if ! command -v convert >/dev/null 2>&1; then
    echo "[*] ImageMagick (convert) が見つかりません。自動インストールを開始します..."
    apt-get update && apt-get install -y imagemagick
fi

# カーネルのDRMからプライマリモニターの物理解像度を直接取得
RES=$(cat /sys/class/drm/*/modes 2>/dev/null | head -n 1)
RES=${RES:-1920x1080}
echo "[*] 検出されたモニター解像度: $RES"

if [ -z "$1" ] || [ ! -f "$1" ]; then
    echo "[!] エラー: 画像ファイルが指定されていないか、見つかりません。"
    echo "使い方: sudo ./bg_change.sh /path/to/your/image.jpg"
    exit 1
fi

SRC_IMG="$1"
echo "[*] 画像を ${RES} に合わせてアスペクト比を維持したまま中央トリミングしています..."

# 画面解像度に合わせて画像をトリミング＆リサイズし、login-background.png を上書き
convert "$SRC_IMG" -resize "${RES}^" -gravity center -extent "${RES}" "$TARGET_IMG"
chmod 644 "$TARGET_IMG"

if [ -f "${BIN_DIR}/install_gdm_bg.py" ]; then
    echo "[*] GDMへの適用スクリプト (install_gdm_bg.py) を実行します..."
    python3 "${BIN_DIR}/install_gdm_bg.py" "${BUILD_DIR}"
else
    echo "[-] エラー: ${BIN_DIR}/install_gdm_bg.py が見つかりません。"
    exit 1
fi

echo "=================================================="
echo "[+] 完了しました! (適用解像度: $RES)"
echo "    次回のログアウトまたは再起動時に新しい背景が適用されます。"
echo "    ※ 今すぐ確認する場合: sudo systemctl restart gdm3"
echo "=================================================="
