#!/bin/bash
set -e

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THEME_NAME="$(basename "${THEME_DIR}")"
GREETER_CONF="/etc/gdm3/greeter.dconf-defaults"

echo "=================================================="
echo " [*] Kawaiintu Initialization & Trademark Removal Script (${THEME_NAME})"
echo "=================================================="

if [ "$EUID" -ne 0 ]; then
  echo "[!] Error: This script must be run with sudo."
  exit 1
fi

echo "[*] Completely removing Ubuntu trademarks and logos from GDM..."
sed -i "s|^#* *logo=.*|logo=''|g" "$GREETER_CONF"
sed -i "s|^#* *fallback-logo=.*|fallback-logo=''|g" "$GREETER_CONF"
dconf update
echo "[+] Logo settings have been completely disabled."

echo "[*] Restoring GDM theme priority to system default..."
if command -v update-alternatives &> /dev/null; then
    update-alternatives --auto gdm-theme.gresource
fi

echo "[*] Overriding desktop environment theme settings to system default..."
# Execute only if an interactive user session exists (avoids ISO build/chroot issues)
if [ -n "$SUDO_USER" ] && [ "$SUDO_USER" != "root" ]; then
    REAL_UID=$(id -u "$SUDO_USER")
    if [ -S "/run/user/${REAL_UID}/bus" ]; then
        export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${REAL_UID}/bus"
        
        sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" dconf write /org/gnome/desktop/interface/gtk-theme "'Adwaita'"
        sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" dconf write /org/gnome/desktop/interface/color-scheme "'default'"
        sudo -u "$SUDO_USER" DBUS_SESSION_BUS_ADDRESS="$DBUS_SESSION_BUS_ADDRESS" dconf write /org/gnome/shell/extensions/user-theme/name "'Default'"
        
        echo "[+] Successfully restored GTK/Shell theme settings for user ($SUDO_USER). (Icon settings retained)"
    else
        echo "  -> D-Bus session not found. Assuming ISO build environment, skipping immediate user UI restoration."
    fi
else
    echo "  -> Interactive user not found. Only system settings were initialized."
fi

echo "=================================================="
echo "[+] All initialization and trademark removal completed!"
echo "    Please restart GDM with: sudo systemctl restart gdm3"
echo "=================================================="
